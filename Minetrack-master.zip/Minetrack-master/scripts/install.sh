apt-get install git npm nodejs-legacy sqlite3
npm install
sh start.sh