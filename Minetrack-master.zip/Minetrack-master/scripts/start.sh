while true;
do
        /usr/bin/nodejs app.js 
        sleep 5
done